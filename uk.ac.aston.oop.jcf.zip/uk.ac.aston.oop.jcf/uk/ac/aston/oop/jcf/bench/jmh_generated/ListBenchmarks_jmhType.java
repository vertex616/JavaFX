package uk.ac.aston.oop.jcf.bench.jmh_generated;
public class ListBenchmarks_jmhType extends ListBenchmarks_jmhType_B3 {
}

